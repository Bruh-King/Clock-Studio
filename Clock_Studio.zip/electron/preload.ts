import { contextBridge } from "electron";

contextBridge.exposeInMainWorld("electronAPI", {
  // You can add IPC calls here if needed in the future
});
