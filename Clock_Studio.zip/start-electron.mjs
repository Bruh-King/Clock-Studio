import { spawn } from "child_process";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Start Electron
const electron = spawn("electron", ["."], {
  cwd: __dirname,
  stdio: "inherit",
});

electron.on("close", (code) => {
  process.exit(code);
});
