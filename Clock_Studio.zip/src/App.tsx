import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { ClockCanvas } from "./components/ClockCanvas";
import { Sidebar } from "./components/Sidebar";
import { useClock } from "./hooks/useClock";
import {
  DEFAULT_SETTINGS,
  loadSettings,
  saveSettings,
} from "./lib/settings";
import type { Settings } from "./lib/settings";

export default function App() {
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const now = useClock();

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  const update = <K extends keyof Settings>(key: K, value: Settings[K]) => {
    setSettings((s) => ({ ...s, [key]: value }));
  };

  const reset = () => {
    localStorage.removeItem("clock-studio-settings-v1");
    setSettings(DEFAULT_SETTINGS);
  };

  return (
    <div className="flex h-full w-full flex-col lg:flex-row bg-[#2c2c2e]">
      <ClockCanvas settings={settings} now={now} />
      
      {sidebarOpen && (
        <Sidebar settings={settings} update={update} reset={reset} />
      )}
      
      {/* Toggle button */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="absolute bottom-4 right-4 lg:bottom-auto lg:top-1/2 lg:-translate-y-1/2 lg:right-0 flex items-center justify-center h-8 w-8 rounded-lg bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition-all border border-white/10"
        title={sidebarOpen ? "Close sidebar" : "Open sidebar"}
      >
        {sidebarOpen ? (
          <ChevronRight size={18} />
        ) : (
          <ChevronLeft size={18} />
        )}
      </button>
    </div>
  );
}
