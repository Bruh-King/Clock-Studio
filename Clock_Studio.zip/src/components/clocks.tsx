import { fontById } from "../lib/settings";
import type { Settings } from "../lib/settings";

export function DigitalClock({
  settings,
  now,
  maxFontSize,
}: {
  settings: Settings;
  now: Date;
  maxFontSize: number;
}) {
  const font = fontById(settings.fontId);
  const h = now.getHours();
  const hours = settings.hour12 ? h % 12 || 12 : h;
  const hh = settings.hour12 ? String(hours) : String(hours).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  const ampm = h < 12 ? "AM" : "PM";
  const fontSize = Math.max(36, Math.min(settings.clockSize, maxFontSize));

  const shadow = settings.textShadow
    ? "0 2px 10px rgba(0,0,0,0.35), 0 8px 48px rgba(0,0,0,0.45)"
    : "none";

  const dateStr = now.toLocaleDateString(undefined, {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  return (
    <div
      className="flex select-none flex-col items-center"
      style={{ fontFamily: font.css, color: settings.clockColor, textShadow: shadow }}
    >
      <div
        className="flex items-baseline whitespace-nowrap font-bold leading-none tracking-tight tabular-nums"
        style={{ fontSize }}
      >
        <span>
          {hh}
          <span className="opacity-80">:</span>
          {mm}
          {settings.showSeconds && (
            <>
              <span className="opacity-80">:</span>
              <span className="opacity-95">{ss}</span>
            </>
          )}
        </span>
        {settings.hour12 && (
          <span className="ml-3 font-semibold tracking-widest" style={{ fontSize: fontSize * 0.28 }}>
            {ampm}
          </span>
        )}
      </div>

      {settings.showDate && (
        <div
          className="mt-4 whitespace-nowrap font-medium tracking-[0.14em] uppercase opacity-80"
          style={{ fontSize: Math.max(10, fontSize * 0.13), letterSpacing: "0.16em" }}
        >
          {dateStr}
        </div>
      )}
    </div>
  );
}

export function AnalogClock({
  settings,
  now,
  maxDiameter,
}: {
  settings: Settings;
  now: Date;
  maxDiameter: number;
}) {
  const size = Math.max(120, Math.min(settings.clockSize, maxDiameter));
  const h = now.getHours() % 12;
  const m = now.getMinutes();
  const s = now.getSeconds() + now.getMilliseconds() / 1000;
  const hourAngle = h * 30 + m * 0.5 + (s / 60) * 0.5;
  const minuteAngle = m * 6 + (s / 60) * 6;
  const secondAngle = s * 6;

  const faceFill =
    settings.bgColor && settings.bgColor.toLowerCase() !== "#ffffff"
      ? "rgba(255,255,255,0.09)"
      : "rgba(0,0,0,0.05)";

  const ticks = Array.from({ length: 60 }, (_, i) => i);

  const shadow = settings.textShadow
    ? "drop-shadow(0 2px 8px rgba(0,0,0,0.4)) drop-shadow(0 6px 24px rgba(0,0,0,0.35))"
    : "none";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      className="max-h-full max-w-full select-none"
      style={{ filter: shadow }}
    >
      {/* face */}
      <circle cx="50" cy="50" r="48.5" fill={faceFill} stroke={settings.clockColor} strokeWidth="2.2" />

      {/* ticks */}
      {ticks.map((i) => {
        const major = i % 5 === 0;
        const angle = i * 6;
        return (
          <line
            key={i}
            x1="50"
            y1={major ? 7 : 9}
            x2="50"
            y2={major ? 12 : 10.5}
            stroke={settings.clockColor}
            strokeWidth={major ? 2.4 : 1.1}
            strokeLinecap="round"
            opacity={major ? 1 : 0.55}
            transform={`rotate(${angle} 50 50)`}
          />
        );
      })}

      {/* hour hand */}
      <line
        x1="50"
        y1="54"
        x2="50"
        y2="29"
        stroke={settings.clockColor}
        strokeWidth="3.6"
        strokeLinecap="round"
        transform={`rotate(${hourAngle} 50 50)`}
      />
      {/* minute hand */}
      <line
        x1="50"
        y1="56"
        x2="50"
        y2="18"
        stroke={settings.clockColor}
        strokeWidth="2.6"
        strokeLinecap="round"
        transform={`rotate(${minuteAngle} 50 50)`}
      />
      {/* second hand */}
      {settings.showSeconds && (
        <line
          x1="50"
          y1="60"
          x2="50"
          y2="15"
          stroke={settings.clockColor}
          strokeWidth="1.2"
          strokeLinecap="round"
          opacity="0.9"
          transform={`rotate(${secondAngle} 50 50)`}
        />
      )}

      {/* center cap */}
      <circle cx="50" cy="50" r="4.2" fill={settings.clockColor} />
      <circle cx="50" cy="50" r="1.9" fill="rgba(20,20,24,0.45)" />
    </svg>
  );
}
