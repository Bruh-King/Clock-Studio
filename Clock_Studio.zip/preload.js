// Preload script - empty for now but needed for security
