import { AnalogClock, DigitalClock } from "./clocks";
import { useElementSize } from "../hooks/useClock";
import type { Settings } from "../lib/settings";

export function ClockCanvas({ settings, now }: { settings: Settings; now: Date }) {
  const [ref, { width, height }] = useElementSize<HTMLDivElement>();

  return (
    <div
      ref={ref}
      className="relative flex min-h-0 flex-1 items-center justify-center overflow-hidden"
      style={{ background: settings.bgColor }}
    >
      {/* uploaded background image */}
      {settings.bgImage && (
        <img
          src={settings.bgImage}
          alt=""
          draggable={false}
          className="pointer-events-none absolute inset-0 h-full w-full"
          style={{
            objectFit: settings.bgImageFit,
            opacity: settings.bgImageOpacity / 100,
            filter: settings.bgImageBlur ? `blur(${settings.bgImageBlur}px)` : undefined,
          }}
        />
      )}

      {/* soft inner vignette for depth */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,rgba(0,0,0,0.22)_100%)]" />

      {/* centered clock */}
      <div className="relative z-10 flex max-h-full items-center justify-center px-6 py-8">
        {settings.style === "digital" ? (
          <DigitalClock
            settings={settings}
            now={now}
            maxFontSize={Math.max(60, Math.min(width * 0.66, height * 0.4))}
          />
        ) : (
          <AnalogClock
            settings={settings}
            now={now}
            maxDiameter={Math.max(120, Math.min(width * 0.6, height * 0.72))}
          />
        )}
      </div>
    </div>
  );
}
