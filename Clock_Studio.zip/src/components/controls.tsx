import type { CSSProperties, ReactNode } from "react";
import { Check } from "lucide-react";
import { cn } from "../utils/cn";

export function Section({
  title,
  icon,
  children,
  action,
}: {
  title: string;
  icon?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
}) {
  return (
    <section>
      <div className="mb-2 flex items-center justify-between px-1">
        <h3 className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.09em] text-white/40">
          {icon}
          {title}
        </h3>
        {action}
      </div>
      <div className="space-y-4 rounded-xl border border-white/[0.06] bg-white/[0.05] p-3.5">
        {children}
      </div>
    </section>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label?: string;
}) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-3 text-left"
    >
      {label && <span className="text-[13px] text-white/80">{label}</span>}
      <span
        className={cn(
          "relative h-[22px] w-[38px] shrink-0 rounded-full transition-colors duration-200",
          checked ? "bg-[#0a84ff]" : "bg-[rgba(120,120,128,0.35)]"
        )}
      >
        <span
          className={cn(
            "absolute left-[2px] top-[2px] h-[18px] w-[18px] rounded-full bg-white shadow-md transition-transform duration-200",
            checked && "translate-x-[16px]"
          )}
        />
      </span>
    </button>
  );
}

export function SliderRow({
  label,
  value,
  min,
  max,
  step = 1,
  onChange,
  format,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step?: number;
  onChange: (v: number) => void;
  format?: (v: number) => string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div className="mb-0.5 flex items-baseline justify-between">
        <span className="text-[13px] text-white/80">{label}</span>
        <span className="text-[11px] font-medium tabular-nums text-white/45">
          {format ? format(value) : value}
        </span>
      </div>
      <input
        type="range"
        className="mac-range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ "--pct": `${pct}%` } as CSSProperties}
      />
    </div>
  );
}

export function Segmented<T extends string>({
  value,
  onChange,
  options,
  className,
}: {
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: ReactNode }[];
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex rounded-[9px] bg-[rgba(120,120,128,0.22)] p-[2px]",
        className
      )}
    >
      {options.map((o) => (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          className={cn(
            "flex flex-1 items-center justify-center gap-1.5 rounded-[7px] px-2 py-[5px] text-[12px] font-medium transition-all duration-150",
            value === o.value
              ? "bg-white text-black shadow-sm"
              : "text-white/65 hover:text-white/90"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Swatches({
  colors,
  value,
  onChange,
  cols = 6,
}: {
  colors: string[];
  value: string;
  onChange: (c: string) => void;
  cols?: number;
}) {
  return (
    <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))` }}>
      {colors.map((c) => {
        const active = c.toLowerCase() === value.toLowerCase();
        return (
          <button
            key={c}
            title={c}
            onClick={() => onChange(c)}
            className={cn(
              "flex h-7 items-center justify-center rounded-lg border transition-transform hover:scale-[1.06] active:scale-95",
              active
                ? "border-white/70 ring-2 ring-[#0a84ff] ring-offset-1 ring-offset-[#232326]"
                : "border-black/25"
            )}
            style={{ background: c }}
          >
            {active && (
              <Check
                size={13}
                strokeWidth={3.5}
                className={cn(
                  "drop-shadow-[0_1px_1px_rgba(0,0,0,0.5)]",
                  isDark(c) ? "text-white" : "text-black/70"
                )}
              />
            )}
          </button>
        );
      })}
    </div>
  );
}

function isDark(hex: string): boolean {
  const m = hex.replace("#", "");
  const full = m.length === 3 ? m.split("").map((c) => c + c).join("") : m;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return 0.299 * r + 0.587 * g + 0.114 * b < 140;
}

export function ColorWell({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (c: string) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="text-[13px] text-white/80">{label}</span>
      <div className="flex items-center gap-2">
        <span className="text-[11px] tabular-nums text-white/40">{value.toUpperCase()}</span>
        <span className="relative inline-flex h-[30px] w-[52px] overflow-hidden rounded-lg border border-white/15">
          <input
            type="color"
            className="mac-colorwell"
            value={value}
            onChange={(e) => onChange(e.target.value)}
          />
        </span>
      </div>
    </div>
  );
}
