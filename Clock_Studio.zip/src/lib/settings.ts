export type ClockStyle = "digital" | "analog";
export type BgFit = "cover" | "contain";

export interface Settings {
  style: ClockStyle;
  fontId: string;
  clockColor: string;
  clockSize: number;
  showSeconds: boolean;
  hour12: boolean;
  showDate: boolean;
  textShadow: boolean;
  bgColor: string;
  bgImage: string | null;
  bgImageOpacity: number;
  bgImageBlur: number;
  bgImageFit: BgFit;
}

export interface FontDef {
  id: string;
  label: string;
  css: string;
}

export const FONTS: FontDef[] = [
  { id: "system", label: "System", css: `-apple-system, BlinkMacSystemFont, "SF Pro Display", "Helvetica Neue", "Inter", sans-serif` },
  { id: "rounded", label: "Rounded", css: `ui-rounded, "SF Pro Rounded", "Nunito", "Hiragino Maru Gothic ProN", sans-serif` },
  { id: "mono", label: "Monospace", css: `ui-monospace, "SF Mono", "JetBrains Mono", Menlo, monospace` },
  { id: "serif", label: "Serif", css: `Georgia, "Playfair Display", "Times New Roman", serif` },
  { id: "display", label: "Orbitron", css: `"Orbitron", sans-serif` },
  { id: "terminal", label: "Terminal", css: `"VT323", monospace` },
  { id: "script", label: "Pacifico", css: `"Pacifico", cursive` },
  { id: "hand", label: "Caveat", css: `"Caveat", cursive` },
  { id: "grotesk", label: "Grotesk", css: `"Space Grotesk", sans-serif` },
];

export const fontById = (id: string): FontDef =>
  FONTS.find((f) => f.id === id) ?? FONTS[0];

export const CLOCK_SWATCHES = [
  "#ffffff", "#f5f5f7", "#e8eaf6", "#111827", "#0a84ff", "#64d2ff",
  "#30d158", "#ffd60a", "#ff9f0a", "#ff453a", "#ff375f", "#bf5af2",
];

export const BG_SWATCHES = [
  "#0b1020", "#1d1d1f", "#2d2d30", "#f5f5f7", "#ffffff", "#0a84ff",
  "#111827", "#002b36", "#0f0f23", "#fdf6e3", "#ffe4e6", "#e0f2fe",
];

export const DEFAULT_SETTINGS: Settings = {
  style: "digital",
  fontId: "system",
  clockColor: "#e8eaf6",
  clockSize: 168,
  showSeconds: true,
  hour12: false,
  showDate: true,
  textShadow: true,
  bgColor: "#0b1020",
  bgImage: null,
  bgImageOpacity: 100,
  bgImageBlur: 0,
  bgImageFit: "cover",
};

export interface ThemePreset {
  name: string;
  emoji: string;
  overrides: Partial<Settings>;
}

export const THEMES: ThemePreset[] = [
  {
    name: "Midnight",
    emoji: "🌌",
    overrides: { bgColor: "#0b1020", clockColor: "#e8eaf6", fontId: "mono", clockSize: 168, style: "digital", textShadow: true },
  },
  {
    name: "Paper",
    emoji: "📄",
    overrides: { bgColor: "#f5f5f7", clockColor: "#1d1d1f", fontId: "serif", clockSize: 148, style: "digital", textShadow: false },
  },
  {
    name: "Solar",
    emoji: "🌅",
    overrides: { bgColor: "#fdf6e3", clockColor: "#cb4b16", fontId: "system", clockSize: 168, style: "digital", textShadow: false },
  },
  {
    name: "Neon",
    emoji: "⚡",
    overrides: { bgColor: "#0f0f23", clockColor: "#22d3ee", fontId: "display", clockSize: 148, style: "digital", textShadow: true },
  },
  {
    name: "Terminal",
    emoji: "🖥️",
    overrides: { bgColor: "#002b36", clockColor: "#2aa198", fontId: "terminal", clockSize: 190, style: "digital", textShadow: true },
  },
  {
    name: "Rose",
    emoji: "🌹",
    overrides: { bgColor: "#ffe4e6", clockColor: "#9f1239", fontId: "hand", clockSize: 170, style: "digital", textShadow: false },
  },
  {
    name: "Classic",
    emoji: "⌚",
    overrides: { bgColor: "#f5f5f7", clockColor: "#111827", fontId: "system", clockSize: 220, style: "analog", textShadow: false },
  },
  {
    name: "Lunar",
    emoji: "🌙",
    overrides: { bgColor: "#16161f", clockColor: "#ffd60a", fontId: "system", clockSize: 220, style: "analog", textShadow: true },
  },
];

const STORAGE_KEY = "clock-studio-settings-v1";

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(s: Settings) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
  } catch {
    // storage full (large images) — settings still work for the session
  }
}

/* ---- color helpers ---- */

function channel(c: string): number {
  return parseInt(c, 16) / 255;
}

export function relativeLuminance(hex: string): number {
  const clean = hex.replace("#", "");
  const full = clean.length === 3 ? clean.split("").map((c) => c + c).join("") : clean;
  const lin = (v: number) => (v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4));
  return (
    0.2126 * lin(channel(full.slice(0, 2))) +
    0.7152 * lin(channel(full.slice(2, 4))) +
    0.0722 * lin(channel(full.slice(4, 6)))
  );
}

export const isLightColor = (hex: string) => relativeLuminance(hex) > 0.5;

export function withAlpha(hex: string, alpha: number): string {
  const clean = hex.replace("#", "");
  const full = clean.length === 3 ? clean.split("").map((c) => c + c).join("") : clean;
  const a = Math.round(alpha * 255)
    .toString(16)
    .padStart(2, "0");
  return `#${full}${a}`;
}
