import esbuild from "esbuild";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Build main process
await esbuild.build({
  entryPoints: [path.join(__dirname, "electron/main.ts")],
  bundle: true,
  platform: "node",
  target: "node18",
  outfile: path.join(__dirname, "dist/electron/main.js"),
  external: ["electron"],
});

// Build preload script
await esbuild.build({
  entryPoints: [path.join(__dirname, "electron/preload.ts")],
  bundle: true,
  platform: "browser",
  target: "es2020",
  outfile: path.join(__dirname, "dist/electron/preload.js"),
});

console.log("✓ Electron main and preload built successfully");
