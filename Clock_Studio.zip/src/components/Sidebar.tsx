import { useRef } from "react";
import type { ChangeEvent } from "react";
import {
  Clock3,
  ImagePlus,
  Images,
  Palette,
  RotateCcw,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Type,
} from "lucide-react";
import { cn } from "../utils/cn";
import {
  BG_SWATCHES,
  CLOCK_SWATCHES,
  FONTS,
  THEMES,
} from "../lib/settings";
import type { Settings } from "../lib/settings";
import { ColorWell, Section, Segmented, SliderRow, Swatches, Toggle } from "./controls";

export function Sidebar({
  settings,
  update,
  reset,
}: {
  settings: Settings;
  update: <K extends keyof Settings>(key: K, value: Settings[K]) => void;
  reset: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => update("bgImage", reader.result as string);
    reader.readAsDataURL(f);
    e.target.value = "";
  };

  return (
    <aside className="flex w-full shrink-0 flex-col border-t border-white/[0.07] bg-[#232326] lg:w-[320px] lg:border-l lg:border-t-0">
      {/* header */}
      <div className="flex items-center gap-3 border-b border-white/[0.07] px-5 py-4">
        <div className="flex h-9 w-9 items-center justify-center rounded-[10px] bg-gradient-to-br from-[#0a84ff] to-[#5e5ce6] shadow-lg shadow-[#0a84ff]/30">
          <Clock3 size={19} className="text-white" strokeWidth={2.2} />
        </div>
        <div>
          <div className="text-[14px] font-semibold leading-tight text-white">Clock Studio</div>
          <div className="text-[11px] text-white/40">Appearance customization</div>
        </div>
      </div>

      {/* controls */}
      <div className="mac-scroll min-h-0 flex-1 space-y-6 overflow-y-auto px-4 py-5">
        <Section title="Clock Style">
          <Segmented
            value={settings.style}
            onChange={(v) => update("style", v)}
            options={[
              { value: "digital" as const, label: "Digital" },
              { value: "analog" as const, label: "Analog" },
            ]}
          />
        </Section>

        {settings.style === "digital" && (
          <Section title="Typography" icon={<Type size={12} />}>
            <div className="grid gap-1.5">
              {FONTS.map((f) => {
                const active = settings.fontId === f.id;
                return (
                  <button
                    key={f.id}
                    onClick={() => update("fontId", f.id)}
                    className={cn(
                      "flex items-center gap-3 rounded-lg border px-3 py-1.5 text-left transition-colors",
                      active
                        ? "border-[#0a84ff]/60 bg-[#0a84ff]/15"
                        : "border-white/[0.06] hover:bg-white/[0.06]"
                    )}
                  >
                    <span
                      className="w-8 text-center text-[19px] leading-8 text-white"
                      style={{ fontFamily: f.css }}
                    >
                      Aa
                    </span>
                    <span className="text-[12.5px] text-white/80">{f.label}</span>
                    <span
                      className="ml-auto text-[10px] uppercase tracking-wider text-white/30"
                      style={{ fontFamily: f.css }}
                    >
                      {f.label}
                    </span>
                  </button>
                );
              })}
            </div>
            <SliderRow
              label="Clock size"
              value={settings.clockSize}
              min={48}
              max={340}
              onChange={(v) => update("clockSize", v)}
              format={(v) => `${v} px`}
            />
          </Section>
        )}

        {settings.style === "analog" && (
          <Section title="Clock Size" icon={<SlidersHorizontal size={12} />}>
            <SliderRow
              label="Diameter"
              value={settings.clockSize}
              min={120}
              max={420}
              onChange={(v) => update("clockSize", v)}
              format={(v) => `${v} px`}
            />
          </Section>
        )}

        <Section title="Clock Color" icon={<Palette size={12} />}>
          <Swatches
            colors={CLOCK_SWATCHES}
            value={settings.clockColor}
            onChange={(c) => update("clockColor", c)}
          />
          <ColorWell
            label="Custom color"
            value={settings.clockColor}
            onChange={(c) => update("clockColor", c)}
          />
          <Toggle
            checked={settings.textShadow}
            onChange={(v) => update("textShadow", v)}
            label="Drop shadow / glow"
          />
        </Section>

        <Section title="Format">
          <Toggle
            checked={settings.showSeconds}
            onChange={(v) => update("showSeconds", v)}
            label="Show seconds"
          />
          {settings.style === "digital" && (
            <Toggle
              checked={settings.hour12}
              onChange={(v) => update("hour12", v)}
              label="12-hour clock"
            />
          )}
          <Toggle
            checked={settings.showDate}
            onChange={(v) => update("showDate", v)}
            label="Show date"
          />
        </Section>

        <Section title="Background" icon={<Images size={12} />}>
          <Swatches
            colors={BG_SWATCHES}
            value={settings.bgColor}
            onChange={(c) => update("bgColor", c)}
          />
          <ColorWell
            label="Background color"
            value={settings.bgColor}
            onChange={(c) => update("bgColor", c)}
          />

          <div className="border-t border-white/[0.06] pt-3.5">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[13px] text-white/80">Background image</span>
              {settings.bgImage && (
                <button
                  onClick={() => update("bgImage", null)}
                  className="flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-[#ff6b62] transition-colors hover:bg-[#ff6b62]/10"
                >
                  <Trash2 size={11} /> Remove
                </button>
              )}
            </div>

            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onFile} />

            {settings.bgImage ? (
              <div className="space-y-3.5">
                <div className="flex items-center gap-3 rounded-lg border border-white/[0.06] bg-black/25 p-2">
                  <img
                    src={settings.bgImage}
                    alt=""
                    className="h-12 w-16 rounded-md object-cover"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12px] text-white/80">Custom image</div>
                    <div className="text-[10.5px] text-white/35">
                      {Math.round(settings.bgImageOpacity)}% opacity · {settings.bgImageBlur}px blur
                    </div>
                  </div>
                  <button
                    onClick={() => fileRef.current?.click()}
                    className="rounded-md bg-white/10 px-2 py-1 text-[11px] font-medium text-white/85 transition-colors hover:bg-white/20"
                  >
                    Replace
                  </button>
                </div>
                <SliderRow
                  label="Opacity"
                  value={settings.bgImageOpacity}
                  min={10}
                  max={100}
                  onChange={(v) => update("bgImageOpacity", v)}
                  format={(v) => `${v}%`}
                />
                <SliderRow
                  label="Blur"
                  value={settings.bgImageBlur}
                  min={0}
                  max={24}
                  onChange={(v) => update("bgImageBlur", v)}
                  format={(v) => `${v}px`}
                />
                <Segmented
                  value={settings.bgImageFit}
                  onChange={(v) => update("bgImageFit", v)}
                  options={[
                    { value: "cover" as const, label: "Fill" },
                    { value: "contain" as const, label: "Fit" },
                  ]}
                />
              </div>
            ) : (
              <button
                onClick={() => fileRef.current?.click()}
                className="flex w-full items-center justify-center gap-2 rounded-lg border border-dashed border-white/20 py-2.5 text-[12.5px] font-medium text-white/65 transition-colors hover:border-[#0a84ff]/60 hover:bg-[#0a84ff]/10 hover:text-white"
              >
                <ImagePlus size={15} /> Choose image…
              </button>
            )}
          </div>
        </Section>

        <Section title="Presets" icon={<Sparkles size={12} />}>
          <div className="grid grid-cols-2 gap-2">
            {THEMES.map((t) => {
              const bg = t.overrides.bgColor ?? settings.bgColor;
              const fg = t.overrides.clockColor ?? settings.clockColor;
              return (
                <button
                  key={t.name}
                  onClick={() => {
                    Object.entries(t.overrides).forEach(([k, v]) =>
                      update(k as keyof Settings, v as never)
                    );
                  }}
                  className="group flex items-center gap-2.5 rounded-lg border border-white/[0.07] bg-white/[0.04] px-2.5 py-2 text-left transition-all hover:border-white/20 hover:bg-white/[0.08]"
                >
                  <span
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[13px] shadow-inner"
                    style={{ background: bg, color: fg }}
                  >
                    {t.emoji}
                  </span>
                  <span className="truncate text-[12px] font-medium text-white/75 group-hover:text-white">
                    {t.name}
                  </span>
                </button>
              );
            })}
          </div>
        </Section>
      </div>

      {/* footer */}
      <div className="border-t border-white/[0.07] px-4 py-3.5">
        <button
          onClick={reset}
          className="flex w-full items-center justify-center gap-2 rounded-lg border border-white/10 py-2 text-[12.5px] font-medium text-white/75 transition-colors hover:bg-white/[0.07] hover:text-white"
        >
          <RotateCcw size={13} /> Reset to defaults
        </button>
        <p className="mt-2 text-center text-[10.5px] text-white/30">
          Customizations are saved automatically on this device
        </p>
      </div>
    </aside>
  );
}
